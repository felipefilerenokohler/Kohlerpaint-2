# KILLER PAINT — projeto Android inicial

Protótipo-fundação v0.1. Não é uma cópia completa do Clip Studio Paint e ainda não é um APK compilado.

## Incluído
- Tela de desenho por toque
- Pincel básico e seletor de cores
- Ajuste de tamanho
- Borracha
- Desfazer (histórico limitado)
- Limpar tela

## Ainda não incluído
Camadas reais, máscaras, modos de mesclagem, estabilizador avançado, exportação/importação, animação, ferramentas de quadrinhos e IA.

## Compilar pela nuvem com GitHub Actions
1. Crie um repositório novo no GitHub.
2. Envie o conteúdo desta pasta para a raiz do repositório (incluindo a pasta `.github`).
3. Abra a aba Actions e selecione "Build KILLER PAINT APK".
4. Toque em "Run workflow".
5. Quando terminar, abra a execução concluída e baixe o artifact `KILLER-PAINT-APK`.
6. Extraia o ZIP do artifact; dentro estará `app-debug.apk`.

A compilação usa Gradle instalado no runner do GitHub e JDK 17. Este ambiente não compilou nem testou o APK.


## Compilar APK pelo celular usando GitHub
1. Crie um repositório GitHub chamado `Kohlerpaint`.
2. Envie o conteúdo desta pasta para a raiz do repositório, incluindo a pasta oculta `.github/workflows`.
3. Abra a aba **Actions** e selecione **Build KILLER PAINT APK**.
4. Toque em **Run workflow** (ou aguarde a compilação automática após enviar os arquivos).
5. Quando terminar, abra a execução e baixe o artefato **KILLER-PAINT-APK**.
6. Extraia o artefato e instale `app-debug.apk` no Android.

Este é um protótipo inicial de desenho, não uma implementação completa do Clip Studio Paint.
