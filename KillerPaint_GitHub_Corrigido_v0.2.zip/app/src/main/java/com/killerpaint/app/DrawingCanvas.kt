package com.killerpaint.app

import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import android.view.View
import java.util.ArrayDeque

class DrawingCanvas(context: Context) : View(context) {
    var brushColor: Int = Color.BLACK
    var brushSize: Float = 10f
    var eraseMode: Boolean = false
    private val bitmapPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private var bitmap: Bitmap? = null
    private var bitmapCanvas: Canvas? = null
    private var path = Path()
    private var lastX = 0f
    private var lastY = 0f
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val history = ArrayDeque<Bitmap>()

    init { setLayerType(View.LAYER_TYPE_SOFTWARE, null) }

    private fun ensureBitmap() {
        if (width <= 0 || height <= 0) return
        if (bitmap == null || bitmap!!.width != width || bitmap!!.height != height) {
            bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
            bitmapCanvas = Canvas(bitmap!!)
            bitmapCanvas?.drawColor(Color.WHITE)
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        ensureBitmap()
        canvas.drawColor(Color.rgb(220,222,228))
        bitmap?.let { canvas.drawBitmap(it, 0f, 0f, bitmapPaint) }
        stroke.color = if (eraseMode) Color.WHITE else brushColor
        stroke.strokeWidth = if (eraseMode) brushSize * 2.5f else brushSize
        canvas.drawPath(path, stroke)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        ensureBitmap()
        val x = event.x
        val y = event.y
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                saveHistory()
                path = Path().apply { moveTo(x, y) }
                lastX = x
                lastY = y
                parent?.requestDisallowInterceptTouchEvent(true)
                invalidate()
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                path.quadTo(lastX, lastY, (lastX + x) / 2f, (lastY + y) / 2f)
                lastX = x
                lastY = y
                invalidate()
                return true
            }
            MotionEvent.ACTION_UP -> {
                stroke.color = if (eraseMode) Color.WHITE else brushColor
                stroke.strokeWidth = if (eraseMode) brushSize * 2.5f else brushSize
                bitmapCanvas?.drawPath(path, stroke)
                path.reset()
                invalidate()
                return true
            }
        }
        return true
    }

    private fun saveHistory() {
        bitmap?.let {
            if (history.size >= 12) history.removeFirst()
            history.addLast(it.copy(Bitmap.Config.ARGB_8888, true))
        }
    }

    fun undo() {
        if (history.isNotEmpty()) {
            bitmap = history.removeLast()
            bitmapCanvas = Canvas(bitmap!!)
            invalidate()
        }
    }

    fun clearCanvas() {
        saveHistory()
        bitmapCanvas?.drawColor(Color.WHITE)
        invalidate()
    }
}
