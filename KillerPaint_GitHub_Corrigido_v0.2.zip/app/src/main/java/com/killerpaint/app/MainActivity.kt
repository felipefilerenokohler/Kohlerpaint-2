package com.killerpaint.app

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.*
import android.graphics.drawable.GradientDrawable

class MainActivity : Activity() {
    private lateinit var canvas: DrawingCanvas
    private val colors = listOf(Color.BLACK, Color.RED, Color.BLUE, Color.GREEN, Color.MAGENTA, Color.YELLOW, Color.WHITE)
    private var selectedColor = Color.BLACK

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(17,19,26)
        window.navigationBarColor = Color.rgb(17,19,26)

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(17,19,26))
        }
        val header = TextView(this).apply {
            text = "KILLER PAINT"
            textSize = 21f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER_VERTICAL
            setPadding(18, 12, 12, 12)
            setBackgroundColor(Color.rgb(27,30,41))
        }
        page.addView(header, LinearLayout.LayoutParams(-1, 58))

        val tools = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(6, 6, 6, 6)
            setBackgroundColor(Color.rgb(34,37,50))
        }
        fun tool(label: String, action: () -> Unit) {
            val b = Button(this).apply {
                text = label
                textSize = 11f
                isAllCaps = false
                setTextColor(Color.WHITE)
                setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(57,61,79)))
                setOnClickListener { action() }
            }
            tools.addView(b, LinearLayout.LayoutParams(0, 48, 1f).apply { setMargins(3,0,3,0) })
        }
        tool("Desfazer") { canvas.undo() }
        tool("Borracha") { canvas.eraseMode = !canvas.eraseMode }
        tool("Limpar") { canvas.clearCanvas() }
        page.addView(tools, LinearLayout.LayoutParams(-1, 60))

        canvas = DrawingCanvas(this)
        page.addView(canvas, LinearLayout.LayoutParams(-1, 0, 1f))

        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(10, 8, 10, 10)
            setBackgroundColor(Color.rgb(27,30,41))
        }
        val palette = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        colors.forEach { c ->
            val swatch = View(this).apply {
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(c)
                    setStroke(2, Color.LTGRAY)
                }
                setOnClickListener { selectedColor = c; canvas.brushColor = c; canvas.eraseMode = false }
            }
            palette.addView(swatch, LinearLayout.LayoutParams(34,34).apply { setMargins(7,2,7,2) })
        }
        bottom.addView(palette, LinearLayout.LayoutParams(-1, 42))
        val sizeLabel = TextView(this).apply { text = "Tamanho do pincel"; setTextColor(Color.WHITE); textSize = 12f }
        bottom.addView(sizeLabel)
        val size = SeekBar(this).apply {
            max = 80
            progress = 8
            setOnSeekBarChangeListener(object: SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) { canvas.brushSize = (progress + 2).toFloat() }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }
        bottom.addView(size)
        page.addView(bottom, LinearLayout.LayoutParams(-1, 105))
        setContentView(page)
    }
}
